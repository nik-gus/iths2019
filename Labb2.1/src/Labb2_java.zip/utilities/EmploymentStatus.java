package utilities;

public enum EmploymentStatus {
	PROBATIONARY, PERMANENT;
}
